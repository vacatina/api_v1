import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import RoomCategory from './RoomCategory';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/room-category" component={RoomCategory} />
                {/* Add other routes here */}
            </Switch>
        </Router>
    );
}

export default App;
