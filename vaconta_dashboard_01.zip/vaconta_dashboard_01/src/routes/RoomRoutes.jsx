import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Roomlist from '../pages/Rooms/RoomsList';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/room-list" component={Roomlist} />
                {/* Add other routes here */}
            </Switch>
        </Router>
    );
}

export default App;