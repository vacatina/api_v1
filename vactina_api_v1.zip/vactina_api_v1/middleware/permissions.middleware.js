const UserRight = require('../models/userright.model');

// Middleware to check if the user has the required permission
const checkPermission = (action) => {
  return (req, res, next) => {
    const userId = req.user.id; // Assuming req.user contains the logged-in user's info

    UserRight.findByUserId(userId, (err, rights) => {
      if (err || !rights) {
        return res.status(403).send({ message: 'User rights not found!' });
      }

      // Check specific permissions based on the action
      if (action === 'create' && !rights.can_create) {
        return res.status(403).send({ message: 'No permission to create!' });
      }
      if (action === 'update' && !rights.can_update) {
        return res.status(403).send({ message: 'No permission to update!' });
      }
      if (action === 'delete' && !rights.can_delete) {
        return res.status(403).send({ message: 'No permission to delete!' });
      }
      if (action === 'view' && !rights.can_view) {
        return res.status(403).send({ message: 'No permission to view!' });
      }

      // Permission granted, proceed to the next middleware or route handler
      next();
    });
  };
};

module.exports = checkPermission;
