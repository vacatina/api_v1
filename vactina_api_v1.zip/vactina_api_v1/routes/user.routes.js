const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const checkPermission = require('../middleware/permissions.middleware');
///const checkPermissions = require('../middleware/checkPermissions');
const checkPermissions = require('../middleware/checkPermissions');


// this Alos Working  but need to develop more
// router.get('/', verifyToken, checkPermission('view'), userController.findAll);
// router.get('/:id', verifyToken, checkPermission('view'), userController.findOne);
// router.put('/:id', verifyToken, checkPermission('update'), userController.update);
// router.delete('/:id', verifyToken, checkPermission('delete'), userController.delete);


router.get('/', verifyToken, checkPermissions('user', 'view'), userController.findAll);
router.get('/:id', verifyToken, checkPermissions('user', 'view'), userController.findOne);
//router.post('users', verifyToken, checkPermissions('user', 'create'), userController.create);
router.put('/:id', verifyToken, checkPermissions('user', 'update'), userController.update);
router.delete('/:id', verifyToken, checkPermissions('user', 'delete'), userController.delete);


module.exports = router;
