const db = require('../config/db.config');

// Employer Model
const Employer = function(employer) {
  this.first_name = employer.first_name;
  this.last_name = employer.last_name;
  this.email = employer.email;
  this.phone_number = employer.phone_number;
  this.address = employer.address;
  this.role = employer.role;
  this.hire_date = employer.hire_date;
  this.salary = employer.salary;
  this.shift = employer.shift;
  this.status = employer.status;
};

// Create Employer
Employer.create = (newEmployer, result) => {
  db.query("INSERT INTO Employer SET ?", newEmployer, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newEmployer });
  });
};

// Find Employer by ID
Employer.findById = (id, result) => {
  db.query(`SELECT * FROM Employer WHERE employer_id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

// Get All Employers
Employer.getAll = result => {
  db.query("SELECT * FROM Employer", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    result(null, res);
  });
};

// Update Employer by ID
Employer.updateById = (id, employer, result) => {
  db.query(
    "UPDATE Employer SET first_name = ?, last_name = ?, email = ?, phone_number = ?, address = ?, role = ?, hire_date = ?, salary = ?, shift = ?, status = ? WHERE employer_id = ?",
    [employer.first_name, employer.last_name, employer.email, employer.phone_number, employer.address, employer.role, employer.hire_date, employer.salary, employer.shift, employer.status, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }

      result(null, { id: id, ...employer });
    }
  );
};

// Delete Employer by ID
Employer.remove = (id, result) => {
  db.query("DELETE FROM Employer WHERE employer_id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

module.exports = Employer;
