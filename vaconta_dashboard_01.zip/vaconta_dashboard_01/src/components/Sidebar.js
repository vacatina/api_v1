import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../Sidebar.css';

function Sidebar() {
    const [isSubMenuOpen, setIsSubMenuOpen] = useState(false);
    // Function to toggle the submenu state
    const toggleSubMenu = () => {
        setIsSubMenuOpen(!isSubMenuOpen);
    };
    return (
        <div className="sidebar bg-custom">
            <div className="sidebar_toggle"><a href="#"><i className="icon-close icons"></i></a></div>
            <div className="pcoded-inner-navbar main-menu">
                <div className="">
                    <div className="pcoded-wrapper">   
                        <nav className="pcoded-navbar">
                            <div className="main-menu-header" style={{ marginTop: '29px' }}>
                                <img className="img-80 img-radius" src="assets/images/avatar-4.jpg" alt="User-Profile-Image" /> {/* */}
                                <div className="user-details">
                                    <span id="more-details">John Doe<i className="fa fa-caret-down"></i></span>
                                </div>
                            </div>
                            <div className="main-menu-content">
                                <ul>
                                    <li className="more-details">
                                        <a href="user-profile.html"><i className="ti-user"></i>View Profile</a>
                                        <a href="#!"><i className="ti-settings"></i>Settings</a>
                                        <a href="auth-normal-sign-in.html"><i className="ti-layout-sidebar-left"></i>Logout</a>
                                    </li>
                                </ul>
                            </div>
                            <div className="p-15 p-b-0">
                                <form className="form-material">
                                    <div className="form-group form-primary">
                                        <input type="text" name="footer-email" className="form-control" required />
                                        <span className="form-bar"></span>
                                        <label className="float-label"><i className="fa fa-search m-r-10"></i>Search Friend</label>
                                    </div>
                                </form>
                            </div>
                            {/* <div className="pcoded-navigation-label" data-i18n="nav.category.navigation">Layout</div> */}
                            <ul className="pcoded-item pcoded-left-item" style={{ 'paddingLeft': '19px','paddingRight': '19px' }} >
                                <li className="active btn btn-primary me1" >
                                    <a href="index.html" className="waves-effect waves-dark">
                                        <span className="pcoded-micon"><i className="ti-home"></i></span>
                                        <span className="pcoded-mtext" data-i18n="nav.dash.main" style={{ color:'white'}}>Dashboard</span>
                                        <span className="pcoded-mcaret"></span>
                                    </a>
                                </li>
                                <li className="pcoded-hasmenu" style={{ 'marginTop': '10px' }}>
                                    <a href="#" onClick={toggleSubMenu} className="waves-effect waves-dark">
                                        <span className="pcoded-micon" style={{ 'paddingLeft': '10px','paddingRight': '10px' }}><i className="ti-layout-grid2-alt"></i></span>
                                        <span className="pcoded-mtext" data-i18n="nav.basic-components.main" style={{ color:'white'}}>HOTEL BOOKING</span>
                                        <span className="pcoded-mcaret" style={{ marginLeft: '60px' }}>{isSubMenuOpen ? '-' : '+'}</span>
                                    </a>
                                    {isSubMenuOpen && (
                                        <ul className="pcoded-submenu" style={{ color:'white'}}>
                                            <li><a href="/hotel-category" className="waves-effect waves-dark" style={{ color:'white'}}>Hotel Catogry</a></li>
                                            <li><a href="/room-category" className="waves-effect waves-dark" style={{ color:'white'}}>Room-Catogory</a></li>
                                            <li><a href="/hotel-detaillist" className="waves-effect waves-dark" style={{ color:'white'}}>Hotel Details</a></li>
                                            <li><a href="/room-list" className="waves-effect waves-dark" style={{ color:'white'}}>Rooms</a></li>
                                            <li><a href="/hotel-reviewlist" className="waves-effect waves-dark" style={{ color:'white'}}>Hotel Reviews</a></li>
                                            <li><a href="/room-reviewlist" className="waves-effect waves-dark"style={{ color:'white'}}>Room Reviews</a></li>
                                            <li><a href="/room-reservation" className="waves-effect waves-dark"style={{ color:'white'}}>Room Reservations</a></li>
                                            <li><a href="/room-cancelations" className="waves-effect waves-dark"style={{ color:'white'}}>Booking Cancelations</a></li>
                                            <li><a href="/hotel-api" className="waves-effect waves-dark"style={{ color:'white'}}>Hotel -API</a></li>
                                      
                                        </ul>
                                    )}
                                </li>
                            </ul>
                        </nav>
                    </div> 
                </div>
            </div>
        </div>
    );
}

export default Sidebar;


   
    