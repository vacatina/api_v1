
import axios from 'axios';

const API_URL = 'http://localhost:3000/api/auth/';

export const login = async (data) => {
    try {
        const res = await axios.post(`${API_URL}login`, data);
        return { success: true, token: res.data.token };
    } catch (error) {
        return { success: false };
    }
};

export const register = async (data) => {
    try {
        await axios.post(`${API_URL}register`, data);
        return { success: true };
    } catch (error) {
        return { success: false };
    }
};

export const logout = () => {
    localStorage.removeItem('token');
};
