const db = require('../config/db.config');

const User = function(user) {
  this.username = user.	username;
  this.email = user.email;
  this.password = user.password;
  this.role_id = user.role_id;
};

// Create a new user
User.create = (newUser, result) => {
  db.query('INSERT INTO users SET ?', newUser, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }
    result(null, { id: res.insertId, ...newUser });
  });
};

// Find user by ID
User.findById = (id, result) => {
  db.query('SELECT * FROM users WHERE id = ?', [id], (err, res) => {
    if (err) {
      result(err, null);
      return;
    }
    if (res.length) {
      result(null, res[0]);
      return;
    }
    result({ kind: 'not_found' }, null);
  });
};

// Find user by email
User.findByEmail = (email, result) => {
  db.query('SELECT * FROM users WHERE email = ?', [email], (err, res) => {
    if (err) {
      result(err, null);
      return;
    }
    if (res.length) {
      result(null, res[0]);
      return;
    }
    result({ kind: 'not_found' }, null);
  });
};

// Find all users
User.findAll = (result) => {
  db.query('SELECT * FROM users', (err, res) => {
    if (err) {
      result(err, null);
      return;
    }
    result(null, res);
  });
};

// Update user by ID
User.updateById = (id, user, result) => {
  db.query(
    'UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?',
    [user.name, user.email, user.password, id],
    (err, res) => {
      if (err) {
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: 'not_found' }, null);
        return;
      }
      result(null, { id: id, ...user });
    }
  );
};

// Remove user by ID
User.remove = (id, result) => {
  db.query('DELETE FROM users WHERE id = ?', [id], (err, res) => {
    if (err) {
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: 'not_found' }, null);
      return;
    }
    result(null, res);
  });
};

User.saveResetToken = (userId, resetToken, result) => {
  const expires = new Date(Date.now() + 3600000);  // 1 hour from now
  const query = 'UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?';

  db.query(query, [resetToken, expires, userId], (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, res);
  });
};


User.findByResetToken = (resetToken, result) => {
  const query = 'SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > NOW()';

  db.query(query, [resetToken], (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: 'not_found' }, null);
  });
};

User.updatePassword = (userId, hashedPassword, result) => {
  const query = 'UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?';

  db.query(query, [hashedPassword, userId], (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, res);
  });
};



















module.exports = User;
