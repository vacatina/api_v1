const db = require('../config/db.config');  // MySQL connection

// HotelReview Model
const HotelReview = function(review) {
  this.hotel_id = review.hotel_id;
  this.user_id = review.user_id;
  this.review_text = review.review_text;
  this.rating = review.rating;
};

// Create Hotel Review
HotelReview.create = (newReview, result) => {
  db.query("INSERT INTO hotel_reviews SET ?", newReview, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    result(null, { id: res.insertId, ...newReview });
  });
};

// Get Reviews by Hotel ID
HotelReview.getByHotelId = (hotelId, result) => {
  db.query(
    `SELECT r.review_id, r.review_text, r.rating, r.created_at, u.username 
     FROM hotel_reviews r 
     JOIN users u ON r.user_id = u.user_id
     WHERE r.hotel_id = ?`, 
    [hotelId],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

      result(null, res);
    }
  );
};

// Get Review by ID
HotelReview.getById = (id, result) => {
  db.query(`SELECT * FROM hotel_reviews WHERE review_id = ?`, [id], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

// Update Hotel Review
HotelReview.updateById = (id, review, result) => {
  db.query(
    `UPDATE hotel_reviews SET review_text = ?, rating = ? WHERE review_id = ?`,
    [review.review_text, review.rating, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }

      result(null, { id: id, ...review });
    }
  );
};

// Delete Hotel Review
HotelReview.remove = (id, result) => {
  db.query("DELETE FROM hotel_reviews WHERE review_id = ?", [id], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

module.exports = HotelReview;
