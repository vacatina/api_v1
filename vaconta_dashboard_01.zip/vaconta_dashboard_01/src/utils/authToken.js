import jwtDecode from 'jwt-decode';

export const getToken = () => {
    return localStorage.getItem('token');
};

export const isAuthenticated = () => {
    const token = getToken();
    if (token) {
        const decodedToken = jwtDecode(token);
        return decodedToken.exp * 1000 > Date.now();
    }
    return false;
};
