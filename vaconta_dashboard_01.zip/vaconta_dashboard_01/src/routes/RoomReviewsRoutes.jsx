import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import RoomRevewList from '../pages/RoomReviews/RoomReviews';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/room-reviewlist" component={RoomRevewList} />
                {/* Add other routes here */}
            </Switch>
        </Router>
    );
}

export default App;