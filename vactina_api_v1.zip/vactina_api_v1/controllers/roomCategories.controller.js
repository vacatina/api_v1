
const RoomCategory = require('../models/roomCategory.model');

// Create a new Room Category
exports.create = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Content cannot be empty!"
    });
  }

  const newRoomCategory = new RoomCategory({
    category_name: req.body.category_name,
    description: req.body.description,
    max_occupancy: req.body.max_occupancy,
    price_per_night: req.body.price_per_night,
    amenities: req.body.amenities,
    status: req.body.status
  });

  RoomCategory.create(newRoomCategory, (err, data) => {
    if (err)
      res.status(500).send({
        message: err.message || "Some error occurred while creating the Room Category."
      });
    else res.send(data);
  });
};

// Retrieve all Room Categories
exports.findAll = (req, res) => {
  RoomCategory.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving room categories."
      });
    else res.send(data);
  });
};

// Retrieve a single Room Category by ID
exports.findOne = (req, res) => {
  RoomCategory.findById(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Room Category with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: `Error retrieving Room Category with id ${req.params.id}`
        });
      }
    } else res.send(data);
  });
};

// Update a Room Category by ID
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Content cannot be empty!"
    });
  }

  RoomCategory.updateById(req.params.id, new RoomCategory(req.body), (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Room Category with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: `Error updating Room Category with id ${req.params.id}`
        });
      }
    } else res.send(data);
  });
};

// Delete a Room Category by ID
exports.delete = (req, res) => {
  RoomCategory.remove(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Room Category with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: `Could not delete Room Category with id ${req.params.id}`
        });
      }
    } else res.send({ message: `Room Category was deleted successfully!` });
  });
};

