const db = require('../config/db.config'); // Adjust the path to your database configuration

// Room Category Model
const RoomCategory = function(roomCategory) {
  this.category_name = roomCategory.category_name;
  this.description = roomCategory.description;
  this.max_occupancy = roomCategory.max_occupancy;
  this.price_per_night = roomCategory.price_per_night;
  this.amenities = roomCategory.amenities;
  this.status = roomCategory.status;
};

// Create Room Category
RoomCategory.create = (newRoomCategory, result) => {
  db.query("INSERT INTO Room_Categories SET ?", newRoomCategory, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newRoomCategory });
  });
};

// Find Room Category by ID
RoomCategory.findById = (id, result) => {
  db.query(`SELECT * FROM Room_Categories WHERE category_id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

// Get All Room Categories
RoomCategory.getAll = (result) => {
  db.query("SELECT * FROM Room_Categories", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    result(null, res);
  });
};

// Update Room Category by ID
RoomCategory.updateById = (id, roomCategory, result) => {
  db.query(
    "UPDATE Room_Categories SET category_name = ?, description = ?, max_occupancy = ?, price_per_night = ?, amenities = ?, status = ? WHERE category_id = ?",
    [
      roomCategory.category_name,
      roomCategory.description,
      roomCategory.max_occupancy,
      roomCategory.price_per_night,
      roomCategory.amenities,
      roomCategory.status,
      id
    ],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }

      result(null, { id: id, ...roomCategory });
    }
  );
};

// Delete Room Category by ID
RoomCategory.remove = (id, result) => {
  db.query("DELETE FROM Room_Categories WHERE category_id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

module.exports = RoomCategory;
