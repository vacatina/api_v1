import React from 'react';

function Dashboard() {
    return (
        <div className="container mt-5" style={{  background: '#455a64' }}>
           <div class="pcoded-inner-content">
                <div class="main-body">  
                     <div class="page-wrapper">
                         <div class="page-body"> 
333333333333333333333
                         </div>   
                    </div>

                </div>  
            </div> 
        </div>
    );
}

export default Dashboard;
