import axios from 'axios';

const API_URL = 'http://localhost:8000/api/';

export const getCategories = () => axios.get(`${API_URL}room-category`);
export const getCategoryById = (id) => axios.get(`${API_URL}room-category/${id}`);
export const createCategory = (categoryData) => axios.post(`${API_URL}room-category/create`, categoryData);
export const updateCategory = (id, categoryData) => axios.put(`${API_URL}room-category/edit/${id}`, categoryData);
export const deleteCategory = (id) => axios.delete(`${API_URL}room-category/delete/${id}`);
