// routes/hotelCategoryRoutes.js
const express = require('express');
const router = express.Router();
const hotelCategoryController = require('../controllers/hotelCategoryController');

router.get('/', hotelCategoryController.getAllCategories);
router.get('/:id', hotelCategoryController.getCategoryById);
router.post('/', hotelCategoryController.createCategory);
router.put('/:id', hotelCategoryController.updateCategory);
router.delete('/:id', hotelCategoryController.deleteCategory);

module.exports = router;
