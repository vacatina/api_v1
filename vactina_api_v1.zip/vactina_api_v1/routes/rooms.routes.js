const express = require('express');
const router = express.Router();
const rooms = require('../controllers/rooms.controller.js');

router.post('/', rooms.create);
router.get('/', rooms.findAll);
router.get('/:roomId', rooms.findOne);
router.put('/:roomId', rooms.update);
router.delete('/:roomId', rooms.delete);

module.exports = router;