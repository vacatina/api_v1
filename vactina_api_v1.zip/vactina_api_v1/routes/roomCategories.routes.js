const express = require('express');
const router = express.Router();
const roomCategories = require('../controllers/roomCategories.controller');

// Create a new Room Category
router.post('/', roomCategories.create);
router.get('/', roomCategories.findAll);
router.get('/:id', roomCategories.findOne);
router.put('/:id', roomCategories.update);
router.delete('/:id', roomCategories.delete);



module.exports = router;
