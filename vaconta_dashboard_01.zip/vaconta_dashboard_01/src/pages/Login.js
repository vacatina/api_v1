import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from '../services/authService';
import '../Login.css'; // Import your CSS file for styles

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        const res = await login({ email, password });
        if (res.success) {
            localStorage.setItem('token', res.token);
            navigate('/dashboard');
        } else {
            alert('Login Failed');
        }
    };

    return (
        <div className="login-container">
            <div className="left-side">
                <img
                     src="/img/loginimage.png"// Replace with your desired image URL
                    alt="Login Visual"
                    className="login-image"
                />
            </div>
            <div className="right-side">
                <h2>Login</h2>
                <form onSubmit={handleLogin}>
                    <div className="form-group">
                        <label>Email</label>
                        <input
                            type="email"
                            className="form-control"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Password</label>
                        <input
                            type="password"
                            className="form-control"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit" className="btn btn-primary">Login</button>
                </form>
                <div className="user-info">
                    <p>Welcome, User!</p>
                    <button className="btn btn-secondary">Register</button>
                </div>
            </div>
        </div>
    );
}

export default Login;
