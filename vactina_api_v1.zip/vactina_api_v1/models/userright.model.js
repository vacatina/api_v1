const db = require('../config/db.config');

const UserRight = function(userRight) {
  this.user_id = userRight.user_id;
  this.role = userRight.role;
  this.can_create = userRight.can_create;
  this.can_update = userRight.can_update;
  this.can_delete = userRight.can_delete;
  this.can_view = userRight.can_view;
};

// Fetch user rights by user ID
UserRight.findByUserId = (userId, result) => {
  db.query('SELECT * FROM user_rights WHERE user_id = ?', [userId], (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: 'not_found' }, null);
  });
};

module.exports = UserRight;
