import React, { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import 'bootstrap/dist/css/bootstrap.min.css';

const RoomCategory = () => {
  const [roomCategories, setRoomCategories] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5; // Number of items per page

  // Fetch data from the endpoint when the component mounts
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:3000/api/roomCat/');
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        setRoomCategories(data);
      } catch (error) {
        console.error("Error fetching room categories:", error);
      }
    };

    fetchData();
  }, []);

  // Calculate the data to be displayed based on the current page
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = roomCategories.slice(indexOfFirstItem, indexOfLastItem);

  // Calculate total pages
  const totalPages = Math.ceil(roomCategories.length / itemsPerPage);

  // Handle page change
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <Layout>
      <div className="container mt-4">
        <h1 className="mb-4">Room Category</h1>
        <p>Welcome to the Room Category page! Here you can manage different room categories for hotels.</p>
        
        {/* New button */}
        <button className="btn btn-primary btn-sm mb-3" style={{ padding: '5px 10px', width: '150px' }}>New Category</button>

        {/* Display the data in a table */}
        <table className="table table-striped table-bordered">
          <thead className="table-dark">
            <tr>
              <th>Category ID</th>
              <th>Category Name</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentItems.map((category) => (
              <tr key={category.category_id}>
                <td>{category.category_id}</td>
                <td>{category.category_name}</td>
                <td>{category.description}</td>
                <td>
                  <button className="btn btn-info btn-sm me-2" style={{ padding: '4px 8px', width: '70px' }}>View</button>
                  <button className="btn btn-warning btn-sm me-2" style={{ padding: '4px 8px', width: '70px' }}>Update</button>
                  <button className="btn btn-danger btn-sm" style={{ padding: '4px 8px', width: '70px' }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Pagination Controls */}
        <div className="d-flex justify-content-center">
          <nav>
            <ul className="pagination">
              {Array.from({ length: totalPages }, (_, i) => (
                <li
                  key={i + 1}
                  className={`page-item ${currentPage === i + 1 ? 'active' : ''}`}
                >
                  <button className="page-link" onClick={() => handlePageChange(i + 1)}>
                    {i + 1}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </Layout>
  );
}

export default RoomCategory;
