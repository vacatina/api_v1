const User = require('../models/user.model');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');  // For generating secure tokens
const nodemailer = require('nodemailer');  // For sending emails



exports.register = (req, res) => {
  const hashedPassword = bcrypt.hashSync(req.body.password, 8);
  
  const newUser = new User({
    username: req.body.username,
    email: req.body.email,
    password: hashedPassword,
    role_id: req.body.role_id,
  });

  User.create(newUser, (err, data) => {
    if (err) return res.status(500).send({ message: err.message });
    res.send({ message: "User registered successfully!", user: data });
  });
};

exports.login = (req, res) => {
    const { email, password } = req.body;

    User.findByEmail(email, (err, user) => {
        if (err) {
            if (err.kind === "not_found") {
                return res.status(404).send({ message: "User not found" });
            }
            return res.status(500).send({ message: "Error retrieving user" });
        }

        // Check if the password matches
        const passwordIsValid = bcrypt.compareSync(password, user.password);

        if (!passwordIsValid) {
            return res.status(401).send({
                token: null,
                message: "Invalid password!"
            });
        }

        // Create a token
        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
            expiresIn: 86400 // 24 hours
        });

        res.status(200).send({
            id: user.id,
            name: user.name,
            email: user.email,
            token: token
        });
    });
};

// Forgot password controller
exports.forgotPassword = (req, res) => {
    const { email } = req.body;
  
    // Check if email is provided
    if (!email) {
      return res.status(400).send({ message: 'Email is required' });
    }
  
    // Find the user by email
    User.findByEmail(email, (err, user) => {
      if (err || !user) {
        return res.status(404).send({ message: 'User with this email does not exist!' });
      }
  
      // Generate a reset token (here using crypto for simplicity)
      const resetToken = crypto.randomBytes(32).toString('hex');
      
      // Save the reset token and its expiration in the database
      User.saveResetToken(user.id, resetToken, (err) => {
        if (err) {
          return res.status(500).send({ message: 'Error saving reset token' });
        }
  
        // Configure your email transport (e.g., using nodemailer)
        const transporter = nodemailer.createTransport({
          service: 'Gmail',
          auth: {
            user: process.env.EMAIL,  // Your email
            pass: process.env.EMAIL_PASSWORD,  // Your email password
          },
        });
  
        // Email content
        const mailOptions = {
          from: process.env.EMAIL,
          to: email,
          subject: 'Password Reset',
          text: `You requested a password reset. Click the following link to reset your password: ${process.env.CLIENT_URL}/reset-password/${resetToken}`,
        };
  
        // Send the email
        transporter.sendMail(mailOptions, (error, info) => {
          if (error) {
            return res.status(500).send({ message: 'Error sending email' });
          }
          res.send({ message: 'Password reset email sent successfully!' });
        });
      });
    });
  };

  exports.resetPassword = (req, res) => {
    const { resetToken, newPassword } = req.body;
  
    // Find the user by reset token and check expiration
    User.findByResetToken(resetToken, (err, user) => {
      if (err || !user) {
        return res.status(400).send({ message: 'Invalid or expired reset token!' });
      }
  
      // If valid, hash the new password and save it
      const hashedPassword = bcrypt.hashSync(newPassword, 10);  // Hash the new password
  
      User.updatePassword(user.id, hashedPassword, (err) => {
        if (err) {
          return res.status(500).send({ message: 'Error updating password' });
        }
  
        res.send({ message: 'Password updated successfully!' });
      });
    });
  };

  exports.logout = (req, res) => {
    res.status(200).send({ message: "User logged out successfully!" });
};

