const db = require('../config/db.config');

// Rooms Model
const Room = function(room) {
  this.room_number = room.room_number;
  this.category_id = room.category_id;
  this.floor_number = room.floor_number;
  this.status = room.status;
  this.max_occupancy = room.max_occupancy;
  this.price_per_night = room.price_per_night;
  this.is_smoking_allowed = room.is_smoking_allowed;
  this.is_pet_friendly = room.is_pet_friendly;
};

// Create Room
Room.create = (newRoom, result) => {
  db.query("INSERT INTO Rooms SET ?", newRoom, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newRoom });
  });
};

// Find Room by ID
Room.findById = (id, result) => {
  db.query(`SELECT * FROM Rooms WHERE room_id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

// Get All Rooms
Room.getAll = result => {
  db.query("SELECT * FROM Rooms", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    result(null, res);
  });
};

// Update Room by ID
Room.updateById = (id, room, result) => {
  db.query(
    "UPDATE Rooms SET room_number = ?, category_id = ?, floor_number = ?, status = ?, max_occupancy = ?, price_per_night = ?, is_smoking_allowed = ?, is_pet_friendly = ? WHERE room_id = ?",
    [room.room_number, room.category_id, room.floor_number, room.status, room.max_occupancy, room.price_per_night, room.is_smoking_allowed, room.is_pet_friendly, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }

      result(null, { id: id, ...room });
    }
  );
};

// Delete Room by ID
Room.remove = (id, result) => {
  db.query("DELETE FROM Rooms WHERE room_id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

module.exports = Room;
