import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom'; // Import useLocation for checking the current path
import Topbar from './components/Topbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';

//import RoomCategoryList from './pages/RoomCategory/RoomCategoryList';
//import CreateRoomCategory from './pages/RoomCategory/CreateRoomCategory';
//import EditRoomCategory from './pages/RoomCategory/EditRoomCategory';

import RoomCategory from './pages/RoomCatogry/RoomCategory';
import CreateRoomCategory from '../src/pages/RoomCatogry/CreateRoomCategory';
import EditRoomCategory from '../src/pages/RoomCatogry/EditRoomCategory';

import HotelCategory from './pages/HotelCatogry/HotelCategory';
import HotleDetailList from './pages/HotelDetails/HotelDetailslist';

import RoomList from './pages/Rooms/RoomsList';
import HotelReviewList from './pages/HotelReviews/HotelReviews';

import RoomReviewList from './pages/RoomReviews/RoomReviews';
import RoomReservations from './pages/RoomReservations/RoomBookings';
import Roomcancelations from './pages/RoomReservations/Roomcancelatons';
import HotelAPI from './pages/HotelAPI/Hotel_API';


function App() {
    const location = useLocation(); // Get the current location
    document.addEventListener('DOMContentLoaded', () => {
        const logoutBtn = document.getElementById("logoutBtn");
    
        if (logoutBtn) {
            logoutBtn.addEventListener("click", function() {
                // Remove token from localStorage
                localStorage.removeItem('token');
    
                // Redirect to login page
                window.location.href = '/login';
            });
        } else {
            console.error('Logout button not found');
        }
    });

    return (
        <div>
            {/* Conditionally show Topbar only on the /dashboard route */}
            {location.pathname === '/dashboard' && <Topbar />}

            <Routes>
                <Route path="/" element={<Navigate to="/login" />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/dashboard" element={<Home />} />
                <Route path="/room-category" element={<RoomCategory />} />
                <Route path="/room-category/create" element={<CreateRoomCategory />} />
                <Route path="/room-category/edit/:id" element={<EditRoomCategory />} />
                <Route path="/hotel-category" element={<HotelCategory />} />
                <Route path="/hotel-detaillist" element={<HotleDetailList />} />
                <Route path="/room-list" element={<RoomList />} />
                <Route path="/hotel-reviewlist" element={<HotelReviewList />} />
                <Route path="/room-reviewlist" element={<RoomReviewList />} />
                <Route path="/room-reservation" element={<RoomReservations />} />
                <Route path="/room-cancelations" element={<Roomcancelations />} />
                <Route path="/hotel-api" element={<HotelAPI />} />
            </Routes>
        </div>
    );
}

function AppWrapper() {
    return (
        <Router>
            <App />
        </Router>
    );
}

export default AppWrapper;