const HotelReview = require('../models/hotelReview.model'); // Assuming you have a HotelReview model

// Get all reviews for a specific hotel
exports.getAllReviews = async (req, res) => {
    try {
        const reviews = await HotelReview.findAll({
            where: { hotel_id: req.params.hotel_id }
        });
        res.json(reviews);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get a specific review by its ID
exports.getReviewById = async (req, res) => {
    try {
        const review = await HotelReview.findByPk(req.params.id);
        if (!review) {
            return res.status(404).json({ message: 'Review not found' });
        }
        res.json(review);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Create a new review
exports.createReview = async (req, res) => {
    const { hotel_id, user_id, review_text, rating } = req.body;
    try {
        const newReview = await HotelReview.create({
            hotel_id,
            user_id,
            review_text,
            rating
        });
        res.status(201).json(newReview);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

// Update a review
exports.updateReview = async (req, res) => {
    try {
        const review = await HotelReview.findByPk(req.params.id);
        if (!review) {
            return res.status(404).json({ message: 'Review not found' });
        }

        review.review_text = req.body.review_text || review.review_text;
        review.rating = req.body.rating || review.rating;

        await review.save();
        res.json(review);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

// Delete a review
exports.deleteReview = async (req, res) => {
    try {
        const review = await HotelReview.findByPk(req.params.id);
        if (!review) {
            return res.status(404).json({ message: 'Review not found' });
        }

        await review.destroy();
        res.json({ message: 'Review deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
