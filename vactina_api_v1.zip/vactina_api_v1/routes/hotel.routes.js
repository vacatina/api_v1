// routes/hotel.routes.js
const express = require('express');
const router = express.Router();
const hotelController = require('../controllers/hotelController');

// Create a new hotel
router.post('/hotels', hotelController.createHotel);

// Get all hotels
router.get('/hotels', hotelController.getAllHotels);

// Get a hotel by ID
router.get('/hotels/:id', hotelController.getHotelById);

// Update hotel by ID
router.put('/hotels/:id', hotelController.updateHotelById);

// Delete hotel by ID
router.delete('/hotels/:id', hotelController.deleteHotelById);

module.exports = router;
