// controllers/hotelController.js
const Hotel = require('../models/hotel.model');

// Create a new hotel
exports.createHotel = (req, res) => {
  const newHotel = new Hotel(req.body);

  Hotel.create(newHotel, (err, hotel) => {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    res.status(201).json(hotel);
  });
};

// Get all hotels
exports.getAllHotels = (req, res) => {
  Hotel.getAll((err, hotels) => {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    res.json(hotels);
  });
};

// Get hotel by ID
exports.getHotelById = (req, res) => {
  const id = req.params.id;

  Hotel.findById(id, (err, hotel) => {
    if (err) {
      if (err.kind === "not_found") {
        return res.status(404).json({ message: "Hotel not found" });
      }
      return res.status(500).json({ message: err.message });
    }
    res.json(hotel);
  });
};

// Update hotel by ID
exports.updateHotelById = (req, res) => {
  const id = req.params.id;
  const hotel = new Hotel(req.body);

  Hotel.updateById(id, hotel, (err, updatedHotel) => {
    if (err) {
      if (err.kind === "not_found") {
        return res.status(404).json({ message: "Hotel not found" });
      }
      return res.status(500).json({ message: err.message });
    }
    res.json(updatedHotel);
  });
};

// Delete hotel by ID
exports.deleteHotelById = (req, res) => {
  const id = req.params.id;

  Hotel.remove(id, (err, result) => {
    if (err) {
      if (err.kind === "not_found") {
        return res.status(404).json({ message: "Hotel not found" });
      }
      return res.status(500).json({ message: err.message });
    }
    res.json({ message: "Hotel deleted successfully", result });
  });
};
