const User = require('../models/user.model');

exports.findAll = (req, res) => {
  User.findAll((err, data) => {
    if (err) return res.status(500).send({ message: err.message });
    res.send(data);
  });
};

exports.findOne = (req, res) => {
  User.findById(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === 'not_found') {
        return res.status(404).send({ message: 'User not found!' });
      }
      return res.status(500).send({ message: err.message });
    }
    res.send(data);
  });
};

exports.update = (req, res) => {
  User.updateById(req.params.id, new User(req.body), (err, data) => {
    if (err) {
      if (err.kind === 'not_found') {
        return res.status(404).send({ message: 'User not found!' });
      }
      return res.status(500).send({ message: err.message });
    }
    res.send({ message: 'User updated successfully!', user: data });
  });
};

exports.delete = (req, res) => {
  User.remove(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === 'not_found') {
        return res.status(404).send({ message: 'User not found!' });
      }
      return res.status(500).send({ message: err.message });
    }
    res.send({ message: 'User deleted successfully!' });
  });
};
