const express = require('express');
const router = express.Router();
const hotelReviewController = require('../controllers/hotelReviewController');

// Get all reviews for a hotel
router.get('/hotel/:hotel_id/reviews', hotelReviewController.getAllReviews);

// Get a single review by ID
router.get('/reviews/:id', hotelReviewController.getReviewById);

// Create a new review
router.post('/reviews', hotelReviewController.createReview);

// Update a review by ID
router.put('/reviews/:id', hotelReviewController.updateReview);

// Delete a review by ID
router.delete('/reviews/:id', hotelReviewController.deleteReview);

module.exports = router;
