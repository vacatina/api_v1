import React, { useState } from 'react';
import '../Topbar.css';
import '../Sidebar.css';
import './Layout.css'; // New CSS for layout structure

function Layout({ children }) {
    const [isSubMenuOpen, setIsSubMenuOpen] = useState(false);

    // Function to toggle the submenu state
    const toggleSubMenu = () => {
        setIsSubMenuOpen(!isSubMenuOpen);
    };
    return (
        <div className="layout-container">
            {/* Topbar Section */}
            <div id="pcoded" className="pcoded">
           
            <nav className="navbar header-navbar pcoded-header">
                <div className="navbar-wrapper">
                    <div className="navbar-logo">
                        <a className="mobile-menu waves-effect waves-light" id="mobile-collapse" href="#!">
                            <i className="ti-menu"></i>
                        </a>
                        <a href="index.html">
                            <img className="img-fluid" src="assets/images/" alt="Vacatina" />
                        </a>
                        <a className="mobile-options waves-effect waves-light">
                            <i className="ti-more"></i>
                        </a>
                    </div>
                    <div className="navbar-container container-fluid">
                        <ul className="nav-left">
                            <li>
                                <div className="sidebar_toggle"><a href="javascript:void(0)"><i className="ti-menu"></i></a></div>
                            </li>
                        </ul>
                        <ul className="nav-right">
                            <li className="header-notification">
                                <a href="#!" className="waves-effect waves-light" style={{ textDecoration: 'none' }}>
                                    <i className="ti-bell"></i>
                                    <span className="badge bg-c-red"></span>
                                </a>
                                <ul className="show-notification">
                                    <li>
                                        <h6>Notifications</h6>
                                        <label className="label label-danger">New</label>
                                    </li>
                                    <li className="waves-effect waves-light">
                                        <div className="media">
                                            <img src="assets/images/avatar-2.jpg" alt="Notification" style={{ width: '40px', height: '40px', borderRadius: '50%' }} />
                                            <div className="media-body">
                                                <h5 className="notification-user">John Doe</h5>
                                                <p className="notification-msg">Lorem ipsum dolor sit amet.</p>
                                                <span className="notification-time">30 minutes ago</span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li className="user-profile header-notification">
                                <a href="#!" className="waves-effect waves-light" style={{ textDecoration: 'none' }}>
                                    <img src="assets/images/avatar-2.jpg" alt="User" style={{ width: '40px', height: '40px', borderRadius: '50%' }} />
                                    <span>John Doe</span>
                                    <i className="ti-angle-down"></i>
                                </a>
                                <ul className="show-notification profile-notification">
                                    <li><a href="#!"><i className="ti-settings"></i> Settings</a></li>
                                    <li><a href="user-profile.html"><i className="ti-user"></i> Profile</a></li>
                                    <li><a href="auth-normal-sign-in.html"><i className="ti-layout-sidebar-left"></i> Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            {/* Sidebar Section */}
          
            <div className="sidebar bg-custom">
                <div className="sidebar_toggle"><a href="#"><i className="icon-close icons"></i></a></div>
                <div className="pcoded-inner-navbar main-menu">
                    <div className="pcoded-wrapper">   
                        <nav className="pcoded-navbar">
                            <div className="main-menu-header" style={{ marginTop: '29px' }}>
                                <img className="img-80 img-radius" src="assets/images/avatar-4.jpg" alt="User-Profile-Image" />
                                <div className="user-details">
                                    <span id="more-details">John Doe<i className="fa fa-caret-down"></i></span>
                                </div>
                            </div>
                            <div className="main-menu-content">
                                <ul>
                                    <li className="more-details">
                                        <a href="user-profile.html"><i className="ti-user"></i> View Profile</a>
                                        <a href="#!"><i className="ti-settings"></i> Settings</a>
                                        <a href="auth-normal-sign-in.html"><i className="ti-layout-sidebar-left"></i> Logout</a>
                                    </li>
                                </ul>
                            </div>
                            <div className="p-15 p-b-0">
                                <form className="form-material">
                                    <div className="form-group form-primary">
                                        <input type="text" name="footer-email" className="form-control" required />
                                        <span className="form-bar"></span>
                                        <label className="float-label"><i className="fa fa-search m-r-10"></i> Search Friend</label>
                                    </div>
                                </form>
                            </div>
                            <ul className="pcoded-item pcoded-left-item" style={{ paddingLeft: '19px', paddingRight: '19px' }}>
                                <li className="active btn btn-primary me-1">
                                    <a href="/dashboard" className="waves-effect waves-dark">
                                        <span className="pcoded-micon"><i className="ti-home"></i></span>
                                        <span className="pcoded-mtext" style={{ color:'white'}}>Dashboard</span>
                                        <span className="pcoded-mcaret"></span>
                                    </a>
                                </li>
                                

                                <li className="pcoded-hasmenu" style={{ marginTop: '10px',color: 'white' }} >
                                    <a href="#" onClick={toggleSubMenu} className="waves-effect waves-dark">
                                        <span className="pcoded-micon" style={{ paddingLeft: '2px', paddingRight: '10px' }}><i className="ti-layout-grid2-alt"></i></span>
                                        <span className="pcoded-mtext"style={{ color:'white'}}>HOTEL BOOKING</span>
                                        <span className="pcoded-mcaret" style={{ marginLeft: '60px' }}>{isSubMenuOpen ? '-' : '+'}</span>
                                    </a>
                                    {isSubMenuOpen && (
                                        <ul className="pcoded-submenu"  style={{ background:'#245bb5'}}>
                                            
                                            <li><a href="/hotel-category" className="waves-effect waves-dark"style={{ color:'white'}}>Hotel Category</a></li>
                                            <li><a href="/room-category" className="waves-effect waves-dark"style={{ color:'white'}}>Room Category</a></li>
                                            <li><a href="/hotel-detaillist" className="waves-effect waves-dark"style={{ color:'white'}}>Hotel Details</a></li>
                                            <li><a href="/room-list" className="waves-effect waves-dark"style={{ color:'white'}}>Rooms</a></li>
                                            <li><a href="/hotel-reviewlist" className="waves-effect waves-dark"style={{ color:'white'}}>Hotel Reviews</a></li>
                                            <li><a href="/room-reviewlist" className="waves-effect waves-dark"style={{ color:'white'}}>Room Reviews</a></li>
                                            <li><a href="/room-reservation" className="waves-effect waves-dark"style={{ color:'white'}}>Room Reservations</a></li>
                                            <li><a href="/room-cancelations" className="waves-effect waves-dark"style={{ color:'white'}}>Booking Cancellations</a></li>
                                            <li><a href="/hotel-api" className="waves-effect waves-dark"style={{ color:'white'}}>Hotel API</a></li>
                                            
                                        </ul>
                                    )}
                                </li>
                            </ul>
                        </nav>
                    </div> 
                </div>
            </div>
           

            {/* Main Content Section */}
            <div className="content">
                <div className="content-wrapper">
                    {children}
                </div>
            </div>
        </div>
        </div>
    );
}

export default Layout;
