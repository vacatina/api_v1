-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2024 at 09:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vacatina`
--

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `employer_id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `role` enum('manager','receptionist','accountant','HR','IT_support','sales','marketing') NOT NULL,
  `hire_date` date DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `shift` enum('morning','afternoon','night') DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`employer_id`, `first_name`, `last_name`, `email`, `phone_number`, `address`, `role`, `hire_date`, `salary`, `shift`, `status`, `created_at`, `updated_at`) VALUES
(2, 'John', 'Doe', 'john.doe@example.com', '1234567890', '123 Main St', 'manager', '2024-01-01', 55000.00, 'morning', 'active', '2024-10-17 20:08:36', '2024-10-17 20:08:36');

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `hotel_id` int(11) NOT NULL,
  `hotel_name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_categories`
--

CREATE TABLE `hotel_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotel_categories`
--

INSERT INTO `hotel_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Fivestar', 'adada', '2024-10-31 16:22:47', '2024-10-31 16:22:47');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_details`
--

CREATE TABLE `hotel_details` (
  `hotel_id` int(11) NOT NULL,
  `hotel_name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `rating` decimal(3,2) NOT NULL,
  `num_rooms` int(11) NOT NULL,
  `room_types` text DEFAULT NULL,
  `price_range` varchar(100) DEFAULT NULL,
  `amenities` text DEFAULT NULL,
  `check_in_time` time NOT NULL,
  `check_out_time` time NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `website_url` varchar(255) DEFAULT NULL,
  `latitude` decimal(9,6) DEFAULT NULL,
  `longitude` decimal(9,6) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `policies` text DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `services` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotel_details`
--

INSERT INTO `hotel_details` (`hotel_id`, `hotel_name`, `location`, `rating`, `num_rooms`, `room_types`, `price_range`, `amenities`, `check_in_time`, `check_out_time`, `contact_number`, `email_address`, `website_url`, `latitude`, `longitude`, `description`, `policies`, `images`, `services`, `created_at`, `updated_at`) VALUES
(1, 'The Grand Oasis', 'New York, USA', 4.70, 200, 'Single, Double, Suite', 'Mid', 'Free Wi-Fi, Parking, Pool, Gym, Restaurant', '15:00:00', '11:00:00', '+12125551234', 'info@thegrandoasis.com', 'http://thegrandoasis.com', 40.712776, -74.005974, 'A luxury hotel located in the heart of New York City with world-class amenities.', 'No cancellation after booking. Pets allowed with an extra fee.', '[\"http://thegrandoasis.com/images/1.jpg\", \"http://thegrandoasis.com/images/2.jpg\"]', 'Spa, Gym, Bar, Restaurant, Room Service', '2024-11-06 17:44:06', '2024-11-06 17:44:06'),
(2, 'Sunset Resort', 'Miami, USA', 4.30, 150, 'Single, Double, Suite', 'High', 'Beach Access, Pool, Bar, Restaurant, Free Wi-Fi', '14:00:00', '12:00:00', '+13055551234', 'contact@sunsetresort.com', 'http://sunsetresort.com', 25.761681, -80.191788, 'A beachfront resort offering stunning views and modern facilities in Miami.', 'Free cancellation within 24 hours of booking. No pets allowed.', '[\"http://sunsetresort.com/images/1.jpg\", \"http://sunsetresort.com/images/2.jpg\"]', 'Bar, Pool, Restaurant, Room Service', '2024-11-06 17:44:06', '2024-11-06 17:44:06'),
(3, 'Mountainview Hotel', 'Denver, USA', 4.50, 120, 'Single, Double', 'Mid', 'Free Wi-Fi, Parking, Restaurant, Pool, Gym', '15:00:00', '12:00:00', '+17203455678', 'contact@mountainviewhotel.com', 'http://mountainviewhotel.com', 39.739236, -104.990251, 'Nestled in the mountains, this hotel offers picturesque views and excellent service.', 'Free cancellation within 48 hours. Pets allowed with a fee.', '[\"http://mountainviewhotel.com/images/1.jpg\", \"http://mountainviewhotel.com/images/2.jpg\"]', 'Gym, Pool, Restaurant, Room Service', '2024-11-06 17:44:06', '2024-11-06 17:44:06'),
(4, 'Ocean Breeze Inn', 'Los Angeles, USA', 4.20, 80, 'Double, Suite', 'Low', 'Free Wi-Fi, Ocean Views, Parking, Restaurant', '16:00:00', '10:00:00', '+13215552233', 'info@oceanbreezeinn.com', 'http://oceanbreezeinn.com', 34.052235, -118.243683, 'A cozy hotel with ocean views located near Los Angeles’ iconic beaches.', 'Free cancellation within 24 hours. No pets allowed.', '[\"http://oceanbreezeinn.com/images/1.jpg\", \"http://oceanbreezeinn.com/images/2.jpg\"]', 'Restaurant, Beach Access, Room Service', '2024-11-06 17:44:06', '2024-11-06 17:44:06'),
(5, 'Skyline Towers', 'Chicago, USA', 4.80, 250, 'Single, Double, Suite', 'High', 'Free Wi-Fi, Parking, Gym, Restaurant, Rooftop Lounge', '14:00:00', '11:00:00', '+13125553344', 'contact@skylinetowers.com', 'http://skylinetowers.com', 41.878113, -87.629799, 'An upscale hotel with breathtaking skyline views and luxurious accommodations in Chicago.', 'No cancellation after booking. Pets allowed with an extra fee.', '[\"http://skylinetowers.com/images/1.jpg\", \"http://skylinetowers.com/images/2.jpg\"]', 'Rooftop Lounge, Spa, Gym, Restaurant, Room Service', '2024-11-06 17:44:06', '2024-11-06 17:44:06'),
(6, 'The Royal Palm', 'Honolulu, Hawaii', 4.60, 180, 'Single, Double, Suite', 'High', 'Free Wi-Fi, Beach Access, Pool, Restaurant, Spa', '15:00:00', '12:00:00', '+18085556677', 'info@royalpalm.com', 'http://royalpalm.com', 21.306944, -157.858337, 'A tropical paradise with elegant rooms and stunning views of the Hawaiian coast.', 'Free cancellation within 72 hours. Pets allowed with extra fee.', '[\"http://royalpalm.com/images/1.jpg\", \"http://royalpalm.com/images/2.jpg\"]', 'Spa, Pool, Beach Access, Room Service, Restaurant', '2024-11-06 17:44:06', '2024-11-06 17:44:06');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_reviews`
--

CREATE TABLE `hotel_reviews` (
  `review_id` int(11) NOT NULL,
  `hotel_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `review_text` text DEFAULT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotel_reviews`
--

INSERT INTO `hotel_reviews` (`review_id`, `hotel_id`, `user_id`, `review_text`, `rating`, `created_at`, `updated_at`) VALUES
(1, 1, 101, 'Amazing hotel with excellent service!', 5, '2024-11-06 18:14:23', '2024-11-06 18:14:23'),
(2, 1, 102, 'Good value for the price. Will come back again.', 4, '2024-11-06 18:14:23', '2024-11-06 18:14:23'),
(3, 2, 103, 'Nice location but the rooms need improvement.', 3, '2024-11-06 18:14:23', '2024-11-06 18:14:23'),
(4, 2, 104, 'The hotel was okay, but the staff were very friendly.', 4, '2024-11-06 18:14:23', '2024-11-06 18:14:23'),
(5, 3, 105, 'Beautiful views but overpriced.', 2, '2024-11-06 18:14:23', '2024-11-06 18:14:23'),
(6, 3, 106, 'Loved the experience! Great facilities and nice ambiance.', 5, '2024-11-06 18:14:23', '2024-11-06 18:14:23'),
(7, 1, 107, 'Comfortable stay, but the food could be better.', 3, '2024-11-06 18:14:23', '2024-11-06 18:14:23'),
(8, 4, 108, 'Had a wonderful stay, will recommend to friends.', 5, '2024-11-06 18:14:23', '2024-11-06 18:14:23');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `resource` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `resource`, `action`) VALUES
(9, 'user', 'view'),
(10, 'user', 'create'),
(11, 'user', 'update'),
(12, 'user', 'delete'),
(13, 'product', 'view'),
(14, 'product', 'create'),
(15, 'product', 'update'),
(16, 'product', 'delete');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `permission_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`id`, `role_id`, `permission_id`) VALUES
(2, 1, 10),
(3, 1, 11),
(4, 1, 12),
(5, 1, 13),
(6, 1, 14),
(7, 1, 15),
(8, 1, 16),
(16, 2, 9);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_id` int(11) NOT NULL,
  `room_number` varchar(10) NOT NULL,
  `category_id` int(11) NOT NULL,
  `floor_number` int(11) DEFAULT NULL,
  `status` enum('available','occupied','maintenance','cleaning') DEFAULT 'available',
  `max_occupancy` int(11) DEFAULT NULL,
  `price_per_night` decimal(10,2) NOT NULL,
  `is_smoking_allowed` tinyint(1) DEFAULT 0,
  `is_pet_friendly` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_id`, `room_number`, `category_id`, `floor_number`, `status`, `max_occupancy`, `price_per_night`, `is_smoking_allowed`, `is_pet_friendly`, `created_at`, `updated_at`) VALUES
(2, '102', 1, 1, 'occupied', 2, 50.00, 0, 0, '2024-10-18 04:45:00', '2024-10-18 04:45:00'),
(3, '201', 2, 2, 'available', 3, 120.00, 0, 1, '2024-10-18 04:45:00', '2024-10-18 04:45:00'),
(4, '202', 3, 2, 'cleaning', 4, 250.00, 0, 0, '2024-10-18 04:45:00', '2024-10-18 04:45:00'),
(5, '301', 4, 3, 'maintenance', 5, 180.00, 1, 1, '2024-10-18 04:45:00', '2024-10-18 04:45:00'),
(6, '302', 5, 3, 'available', 2, 350.00, 0, 0, '2024-10-18 04:45:00', '2024-10-18 04:45:00'),
(7, '1016', 1, 1, 'available', 2, 50.00, 0, 0, '2024-10-18 05:19:33', '2024-10-18 05:19:33');

-- --------------------------------------------------------

--
-- Table structure for table `room_categories`
--

CREATE TABLE `room_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `max_occupancy` int(11) NOT NULL,
  `price_per_night` decimal(10,2) NOT NULL,
  `amenities` text DEFAULT NULL,
  `status` enum('available','unavailable') DEFAULT 'available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_categories`
--

INSERT INTO `room_categories` (`category_id`, `category_name`, `description`, `max_occupancy`, `price_per_night`, `amenities`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Executive Suite', 'Premium suite with personalized services', 2, 350.00, 'WiFi, TV, Mini Bar, Private Butler, Ocean View, Jacuzzi', 'available', '2024-10-18 04:00:16', '2024-10-18 04:00:30'),
(2, 'Deluxe', 'A spacious room with a mini bar and ocean view', 3, 120.00, 'WiFi, TV, Mini Bar, Ocean View', 'available', '2024-10-18 03:38:18', '2024-10-18 03:38:18'),
(3, 'Suite', 'Luxurious suite with separate living area and jacuzzi', 4, 250.00, 'WiFi, TV, Jacuzzi, Mini Bar, Ocean View', 'available', '2024-10-18 03:38:47', '2024-10-18 03:38:47'),
(4, 'Family Room', 'A large room suitable for families with children', 5, 180.00, 'WiFi, TV, Play Area, Kitchenette', 'available', '2024-10-18 03:39:09', '2024-10-18 03:39:09'),
(5, 'Executive Suite', 'Premium suite with personalized services', 2, 350.00, 'WiFi, TV, Mini Bar, Private Butler, Ocean View, Jacuzzi', 'available', '2024-10-18 03:39:36', '2024-10-18 03:39:36'),
(7, 'Executive Suite', 'Premium suite with personalized services', 2, 350.00, 'WiFi, TV, Mini Bar, Private Butler, Ocean View, Jacuzzi', 'available', '2024-10-30 05:18:22', '2024-10-30 05:18:22');

-- --------------------------------------------------------

--
-- Table structure for table `room_images`
--

CREATE TABLE `room_images` (
  `image_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role_id`) VALUES
(1, 'John Doe1', 'john@example1.com', '$2a$08$jiFa0rsgy3JdXh/C3hjMaePS1EEnVAT.6LiCFsgeOfdZDWl5/F6mi', 1),
(2, 'John Doe1', 'john@example1.com', '$2a$08$w6ZxX5idHpR97dr6iCXbT.HTvZI39wjvWehLG3WVh5tR4imE5TXzW', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_rights`
--

CREATE TABLE `user_rights` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `can_create` tinyint(1) DEFAULT NULL,
  `can_update` tinyint(1) DEFAULT NULL,
  `can_delete` tinyint(1) DEFAULT NULL,
  `can_view` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_rights`
--

INSERT INTO `user_rights` (`id`, `user_id`, `role`, `can_create`, `can_update`, `can_delete`, `can_view`) VALUES
(1, 1, 'admin', 1, 1, 1, 1),
(2, 2, 'editor', 1, 1, 0, 1),
(3, 3, 'viewer', 0, 0, 0, 1),
(4, 4, 'contributor', 1, 0, 0, 1),
(5, 5, 'manager', 1, 1, 1, 1),
(6, 6, 'staff', 0, 1, 0, 1),
(7, 7, 'superadmin', 1, 1, 1, 1),
(8, 8, 'moderator', 0, 1, 1, 1),
(9, 9, 'guest', 0, 0, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`employer_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`hotel_id`);

--
-- Indexes for table `hotel_categories`
--
ALTER TABLE `hotel_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_details`
--
ALTER TABLE `hotel_details`
  ADD PRIMARY KEY (`hotel_id`);

--
-- Indexes for table `hotel_reviews`
--
ALTER TABLE `hotel_reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `permission_id` (`permission_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_id`),
  ADD UNIQUE KEY `room_number` (`room_number`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `room_categories`
--
ALTER TABLE `room_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `room_images`
--
ALTER TABLE `room_images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `hotel_id` (`hotel_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `user_rights`
--
ALTER TABLE `user_rights`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `employer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hotels`
--
ALTER TABLE `hotels`
  MODIFY `hotel_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hotel_categories`
--
ALTER TABLE `hotel_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hotel_details`
--
ALTER TABLE `hotel_details`
  MODIFY `hotel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hotel_reviews`
--
ALTER TABLE `hotel_reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `room_categories`
--
ALTER TABLE `room_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `room_images`
--
ALTER TABLE `room_images`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_rights`
--
ALTER TABLE `user_rights`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`);

--
-- Constraints for table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `rooms_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `room_categories` (`category_id`);

--
-- Constraints for table `room_images`
--
ALTER TABLE `room_images`
  ADD CONSTRAINT `room_images_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `room_images_ibfk_2` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`hotel_id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
