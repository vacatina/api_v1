import React from 'react';
import Sidebar from '../components/Sidebar';
import './Home.css'; // Import the CSS file for styling adjustments

function Home() {
    return (
        <div className="d-flex" style={{ height: '100vh' }}>
            <Sidebar />
            <div className="pcoded-content" style={{ flex: 1, padding: '0px' }}>
                <div className="page-header">
                    <div className="page-block" style={{ flex: 1,     'marginTop': '72px' }}>
                        <div className="row align-items-center">
                            <div className="col-md-8">
                                <div className="page-header-title">
                                    <h5 className="m-b-10">Dashboard</h5>
                                    <p className="m-b-0">Welcome to Vacatina Pvt Ltd</p>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <ul className="breadcrumb-title">
                                    <li className="breadcrumb-item">
                                        <a href="index.html"><i className="fa fa-home"></i></a>
                                    </li>
                                    <li className="breadcrumb-item"><a href="#!">Dashboard</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pcoded-inner-content" style={{  background: '#e9f1f4' }}>
                <div class="main-body"  style={{ marginLeft: '248px'}}>  
                   
                    <div class="page-wrapper">
                         <div class="page-body"> 
                             <div class="row"> 
                                <div class="col-xl-3 col-md-6">
                                                    <div class="card">
                                                        <div class="card-block">
                                                            <div class="row align-items-center">
                                                                <div class="col-8">
                                                                    <h4 class="text-c-purple">$30200</h4>
                                                                    <h6 class="text-muted m-b-0">All Earnings</h6>
                                                                </div>
                                                                <div class="col-4 text-right">
                                                                    <i class="fa fa-bar-chart f-28"></i>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="card-footer bg-c-purple bdc">
                                                            <div class="row align-items-center">
                                                                <div class="col-9">
                                                                    <p class="text-white m-b-0">% change</p>
                                                                </div>
                                                                <div class="col-3 text-right">
                                                                    <i class="fa fa-line-chart text-white f-16"></i>
                                                                </div>
                                                            </div>
                
                                                        </div>
                                                    </div>
                                </div>
                                 
                                <div class="col-xl-3 col-md-6">
                                                <div class="card">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-8">
                                                                <h4 class="text-c-green">290+</h4>
                                                                <h6 class="text-muted m-b-0">Air Line</h6>
                                                            </div>
                                                            <div class="col-4 text-right">
                                                                <i class="fa fa-file-text-o f-28"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-footer bg-c-green bcg">
                                                        <div class="row align-items-center">
                                                            <div class="col-9">
                                                                <p class="text-white m-b-0">% change</p>
                                                            </div>
                                                            <div class="col-3 text-right">
                                                                <i class="fa fa-line-chart text-white f-16"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                </div>
                                <div class="col-xl-3 col-md-6">
                                                <div class="card">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-8">
                                                                <h4 class="text-c-red">145</h4>
                                                                <h6 class="text-muted m-b-0">Hotel Bookings</h6>
                                                            </div>
                                                            <div class="col-4 text-right">
                                                                <i class="fa fa-calendar-check-o f-28"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-footer bg-c-red bgr">
                                                        <div class="row align-items-center">
                                                            <div class="col-9">
                                                                <p class="text-white m-b-0">% change</p>
                                                            </div>
                                                            <div class="col-3 text-right">
                                                                <i class="fa fa-line-chart text-white f-16"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                 </div>
                                 <div class="col-xl-3 col-md-6">
                                                <div class="card">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-8">
                                                                <h4 class="text-c-blue">500</h4>
                                                                <h6 class="text-muted m-b-0">Downloads</h6>
                                                            </div>
                                                            <div class="col-4 text-right">
                                                                <i class="fa fa-hand-o-down f-28"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-footer  bgb">
                                                        <div class="row align-items-center">
                                                            <div class="col-9">
                                                                <p class="text-white m-b-0">% change</p>
                                                            </div>
                                                            <div class="col-3 text-right">
                                                                <i class="fa fa-line-chart text-white f-16"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                 </div>

                                 <div class="col-xl-8 col-md-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Sales Analytics</h5>
                                                       
                                                     </div>
                                                </div>
                                               
                                </div>
                                <div class="col-xl-4 col-md-12">
                                        <div class="card">
                                                <div class="card-block">
                                                <div class="row">
                                                        <div class="col">
                                                                <h4>$256.23</h4>
                                                                <p class="text-muted">This Month</p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <label class="label label-success">+20%</label>
                                                            </div>
                                                        </div>
                                                </div>
                                        </div>
                                </div>
                                <div class="card quater-card">
                                        <div class="card-block">
                                                        <h6 class="text-muted m-b-15">This Quarter</h6>
                                                        <h4>$3,9452.50</h4>
                                                        <p class="text-muted">$3,9452.50</p>
                                                        <h5>87</h5>
                                        </div>
                                 </div>
                              </div>
                           </div> 
                           <div class="row"> 
                                <div class="card table-card">  
                                <div class="card-header">
                                    <h5>Projects</h5>
                                        <div class="card-header-right">
                                            <ul class="list-unstyled card-option">
                                                                <li><i class="fa fa fa-wrench open-card-option"></i></li>
                                                                <li><i class="fa fa-window-maximize full-card"></i></li>
                                                                <li><i class="fa fa-minus minimize-card"></i></li>
                                                                <li><i class="fa fa-refresh reload-card"></i></li>
                                                                <li><i class="fa fa-trash close-card"></i></li>
                                            </ul>
                                        </div>
                                        
                                    </div>
                                </div> 

                            </div>


                    </div> 
                </div>  
            </div> 





                {/* Additional content can go here */}
            </div>
        </div>
    );
}

export default Home;