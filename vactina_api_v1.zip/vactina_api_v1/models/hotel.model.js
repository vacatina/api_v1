const db = require('../config/db.config'); // Your MySQL connection

// Hotel Model
const Hotel = function(hotel) {
  this.hotel_name = hotel.hotel_name;
  this.location = hotel.location;
  this.rating = hotel.rating;
  this.num_rooms = hotel.num_rooms;
  this.room_types = hotel.room_types;
  this.price_range = hotel.price_range;
  this.amenities = hotel.amenities;
  this.check_in_time = hotel.check_in_time;
  this.check_out_time = hotel.check_out_time;
  this.contact_number = hotel.contact_number;
  this.email_address = hotel.email_address;
  this.website_url = hotel.website_url;
  this.latitude = hotel.latitude;
  this.longitude = hotel.longitude;
  this.description = hotel.description;
  this.policies = hotel.policies;
  this.images = hotel.images;
  this.services = hotel.services;
};

// Create Hotel
Hotel.create = (newHotel, result) => {
  db.query("INSERT INTO hotel_details SET ?", newHotel, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    result(null, { id: res.insertId, ...newHotel });
  });
};

// Find Hotel by ID
Hotel.findById = (id, result) => {
  db.query(`SELECT * FROM hotel_details WHERE hotel_id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

// Get All Hotels
Hotel.getAll = result => {
  db.query("SELECT * FROM hotel_details", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    result(null, res);
  });
};

// Update Hotel by ID
Hotel.updateById = (id, hotel, result) => {
  db.query(
    `UPDATE hotel_details SET hotel_name = ?, location = ?, rating = ?, num_rooms = ?, room_types = ?, price_range = ?, amenities = ?, check_in_time = ?, check_out_time = ?, contact_number = ?, email_address = ?, website_url = ?, latitude = ?, longitude = ?, description = ?, policies = ?, images = ?, services = ? WHERE hotel_id = ?`,
    [
      hotel.hotel_name, hotel.location, hotel.rating, hotel.num_rooms, hotel.room_types, hotel.price_range, hotel.amenities,
      hotel.check_in_time, hotel.check_out_time, hotel.contact_number, hotel.email_address, hotel.website_url,
      hotel.latitude, hotel.longitude, hotel.description, hotel.policies, hotel.images, hotel.services, id
    ],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }

      result(null, { id: id, ...hotel });
    }
  );
};

// Delete Hotel by ID
Hotel.remove = (id, result) => {
  db.query("DELETE FROM hotel_details WHERE hotel_id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

module.exports = Hotel;
