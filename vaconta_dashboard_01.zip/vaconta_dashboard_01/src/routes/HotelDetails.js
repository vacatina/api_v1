import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import HotelDetailsList from '../pages/HotelDetails/HotelDetailslist';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/hotel-detaillist" component={HotelDetailsList} />
                {/* Add other routes here */}
            </Switch>
        </Router>
    );
}

export default App;
