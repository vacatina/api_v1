import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import HotelReviewList from '../pages/HotelReviews/HotelReviews';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/hotel-reviewlist" component={HotelReviewList} />
                {/* Add other routes here */}
            </Switch>
        </Router>
    );
}

export default App;
