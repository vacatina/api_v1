import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../Sidebar.css';

function Sidebar() {
    // State to track the submenu collapse/expand
    const [isSubMenuOpen, setIsSubMenuOpen] = useState(false);

    // Function to toggle the submenu state
    const toggleSubMenu = () => {
        setIsSubMenuOpen(!isSubMenuOpen);
    };

    return (
        <div className="sidebar bg-custom">
            <ul className="nav flex-column">
                <li className="nav-item">
                    <Link className="nav-link text-white d-flex align-items-center" to="/dashboard">
                        <i className="fas fa-home me-2"></i>
                        Dashboard
                    </Link>
                </li>
                <li className="nav-item">
                    <Link className="nav-link text-white d-flex align-items-center" to="/products">
                        <i className="fas fa-box me-2"></i>
                        AirLine
                    </Link>
                </li>
               
                <li className="nav-item">
                    {/* Toggle submenu */}
                    <a
                        className="nav-link text-white d-flex justify-content-between align-items-center"
                        onClick={toggleSubMenu}
                        data-bs-toggle="collapse"
                        href="#submenu1"
                        role="button"
                        aria-expanded={isSubMenuOpen}
                        aria-controls="submenu1"
                    >
                        <span>
                            <i className="fas fa-cogs me-2"></i>
                            Hotels
                        </span>
                        {/* Dynamically changing arrow icon */}
                        <i className={`fas ${isSubMenuOpen ? 'fa-chevron-up' : 'fa-chevron-down'}`}></i>
                    </a>
                    <div id="submenu1" className={`collapse ${isSubMenuOpen ? 'show' : ''}`}>
                        <Link className="nav-link text-white ms-4" to="/profile">
                                 Room Category
                        </Link>
                        <Link className="nav-link text-white ms-4" to="/privacy">
                                Rooms Details
                        </Link>
                        <Link className="nav-link text-white ms-4" to="/privacy">
                                Hotels Details
                        </Link>
                        <Link className="nav-link text-white ms-4" to="/privacy">
                                Room Reservation
                        </Link>
                        <Link className="nav-link text-white ms-4" to="/privacy">
                                Room Bookings
                        </Link>
                        <Link className="nav-link text-white ms-4" to="/privacy">
                                Cancel Bookings
                        </Link>
                    </div>
                </li>
                <li className="nav-item">
                    <Link className="nav-link text-white d-flex align-items-center" to="/employees">
                        <i className="fas fa-users me-2"></i>
                        Back-office
                    </Link>
                </li>
            </ul>
        </div>
    );
}

export default Sidebar;
