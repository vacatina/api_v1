const jwt = require('jsonwebtoken');

// Middleware to verify Bearer token
const verifyToken = (req, res, next) => {
    // Get token from the Authorization header
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
        return res.status(403).send({ message: "No token provided!" });
    }

    // The token comes in the format: "Bearer <token>"
    const token = authHeader.split(' ')[1];

    if (!token) {
        return res.status(403).send({ message: "Invalid token format!" });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(401).send({ message: "Unauthorized!" });
        }

        // Save user ID to request for further use
        req.userId = decoded.id;
        next();
    });
};

module.exports = verifyToken;
