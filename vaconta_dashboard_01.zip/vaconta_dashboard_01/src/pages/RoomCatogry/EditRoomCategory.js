import React, { useState, useEffect } from 'react';
import { getCategoryById, updateCategory } from '../../services/apiService';
import { useParams, useNavigate } from 'react-router-dom';

const EditRoomCategory = () => {
    const { id } = useParams();
    const [formData, setFormData] = useState({
        category_name: '',
        description: '',
        max_occupancy: '',
        price_per_night: '',
        amenities: '',
        status: '',
    });
    const navigate = useNavigate();

    useEffect(() => {
        fetchCategory();
    }, []);

    const fetchCategory = async () => {
        try {
            const response = await getCategoryById(id);
            setFormData(response.data);
        } catch (error) {
            console.error("Error fetching room category by ID:", error);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await updateCategory(id, formData);
            navigate('/room-category');
        } catch (error) {
            console.error("Error updating room category:", error);
        }
    };

    return (
        <div>
            <h2>Edit Room Category</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="category_name" placeholder="Room Category Name" value={formData.category_name} onChange={handleInputChange} required />
                <textarea name="description" placeholder="Description" value={formData.description} onChange={handleInputChange} required></textarea>
                <input type="number" name="max_occupancy" placeholder="Max Occupancy" value={formData.max_occupancy} onChange={handleInputChange} required />
                <input type="text" name="price_per_night" placeholder="Price per Night" value={formData.price_per_night} onChange={handleInputChange} required />
                <input type="text" name="amenities" placeholder="Amenities" value={formData.amenities} onChange={handleInputChange} required />
                <select name="status" value={formData.status} onChange={handleInputChange} required>
                    <option value="">Select Status</option>
                    <option value="available">Available</option>
                    <option value="unavailable">Unavailable</option>
                </select>
                <button type="submit">Update Room Category</button>
            </form>
        </div>
    );
};

export default EditRoomCategory;
