import React from 'react';
import { Routes } from 'react-router-dom';
import AuthRoutes from './authRoutes';
import DashboardRoutes from './dashboardRoutes';

const AllRoutes = () => {
    return (
        <Routes>
            <AuthRoutes />
            <DashboardRoutes />
        </Routes>
    );
};

export default AllRoutes;
