import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import HotelCategory from '../pages/HotelCatogry/HotelCategory';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/hotel-category" component={HotelCategory} />
                {/* Add other routes here */}
            </Switch>
        </Router>
    );
}

export default App;
