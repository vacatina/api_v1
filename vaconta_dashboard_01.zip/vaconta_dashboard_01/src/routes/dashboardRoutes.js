import React from 'react';
import { Route } from 'react-router-dom';
import Home from '../pages/Home';
import Products from '../pages/Products';
import Employees from '../pages/Employees';

const DashboardRoutes = () => {
    return (
        <>
            <Route path="/dashboard" element={<Home />} />
            <Route path="/products" element={<Products />} />
            <Route path="/employees" element={<Employees />} />
        </>
    );
};

export default DashboardRoutes;
