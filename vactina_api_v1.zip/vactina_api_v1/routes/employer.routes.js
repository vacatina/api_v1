const express = require('express');
const router = express.Router();
const employerController = require('../controllers/employer.controller');

router.post('/', employerController.create);
router.get('/', employerController.findAll);
router.get('/:id', employerController.findOne);
router.put('/:id', employerController.update);
router.delete('/:id', employerController.delete);

module.exports = router;
