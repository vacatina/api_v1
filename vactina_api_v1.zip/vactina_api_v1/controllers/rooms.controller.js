const Room = require('../models/rooms.model.js');

// Create and Save a new Room
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({ message: "Content cannot be empty!" });
    return;
  }

  // Create a Room
  const room = new Room({
    room_number: req.body.room_number,
    category_id: req.body.category_id,
    floor_number: req.body.floor_number,
    status: req.body.status,
    max_occupancy: req.body.max_occupancy,
    price_per_night: req.body.price_per_night,
    is_smoking_allowed: req.body.is_smoking_allowed,
    is_pet_friendly: req.body.is_pet_friendly,
  });

  // Save Room in the database
  Room.create(room, (err, data) => {
    if (err) {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Room."
      });
    } else {
      res.send(data);
    }
  });
};

// Retrieve all Rooms from the database.
exports.findAll = (req, res) => {
  Room.getAll((err, data) => {
    if (err) {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving rooms."
      });
    } else {
      res.send(data);
    }
  });
};

// Find a single Room with a roomId
exports.findOne = (req, res) => {
  Room.findById(req.params.roomId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Room with id ${req.params.roomId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Room with id " + req.params.roomId
        });
      }
    } else {
      res.send(data);
    }
  });
};

// Update a Room identified by the roomId in the request
exports.update = (req, res) => {
  // Validate request
  if (!req.body) {
    return res.status(400).send({
      message: "Content cannot be empty!"
    });
  }

  Room.updateById(req.params.roomId, new Room(req.body), (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Room with id ${req.params.roomId}.`
        });
      } else {
        res.status(500).send({
          message: "Error updating Room with id " + req.params.roomId
        });
      }
    } else {
      res.send(data);
    }
  });
};

// Delete a Room with the specified roomId in the request
exports.delete = (req, res) => {
  Room.remove(req.params.roomId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Room with id ${req.params.roomId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Room with id " + req.params.roomId
        });
      }
    } else {
      res.send({ message: `Room was deleted successfully!` });
    }
  });
};
