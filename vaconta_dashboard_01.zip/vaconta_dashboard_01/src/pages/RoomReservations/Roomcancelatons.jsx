import React from 'react';
import Layout from '../../components/Layout';  // Adjust the path based on your folder structure

function Roomcancelatons() {
    return (
        <Layout>
            <div style={{}}> {/* Add padding or margin as needed */}
                <h1>Room Booking Cancel</h1>
                <p>Welcome to the Room Category page! Here you can manage different room categories for hotels.</p>
          


                {/* Add the rest of your Room Category content here */}
            </div>
        </Layout>
    );
}

export default Roomcancelatons;