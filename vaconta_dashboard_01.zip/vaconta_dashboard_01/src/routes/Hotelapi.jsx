import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Hotelapi from '../pages/HotelAPI/Hotel_API';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/hotel-api" component={Hotelapi} />
                {/* Add other routes here */}
            </Switch>
        </Router>
    );
}

export default App;
