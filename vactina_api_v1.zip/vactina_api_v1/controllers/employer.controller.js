const Employer = require('../models/employer.model');

// Create and Save a new Employer
exports.create = (req, res) => {
  const employer = new Employer({
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    email: req.body.email,
    phone_number: req.body.phone_number,
    address: req.body.address,
    role: req.body.role,
    hire_date: req.body.hire_date,
    salary: req.body.salary,
    shift: req.body.shift,
    status: req.body.status
  });

  Employer.create(employer, (err, data) => {
    if (err)
      res.status(500).send({
        message: err.message || "Some error occurred while creating the Employer."
      });
    else res.send(data);
  });
};

// Retrieve all Employers from the database
exports.findAll = (req, res) => {
  Employer.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving employers."
      });
    else res.send(data);
  });
};

// Find a single Employer by ID
exports.findOne = (req, res) => {
  Employer.findById(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Employer with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Employer with id " + req.params.id
        });
      }
    } else res.send(data);
  });
};

// Update an Employer by the ID in the request
exports.update = (req, res) => {
  Employer.updateById(req.params.id, new Employer(req.body), (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Employer with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Error updating Employer with id " + req.params.id
        });
      }
    } else res.send(data);
  });
};

// Delete an Employer by ID
exports.delete = (req, res) => {
  Employer.remove(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Employer with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Employer with id " + req.params.id
        });
      }
    } else res.send({ message: `Employer was deleted successfully!` });
  });
};
