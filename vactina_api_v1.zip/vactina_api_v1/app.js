const express = require('express');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const employerRoutes = require('./routes/employer.routes');
const roomCategoriesRoutes = require('./routes/roomCategories.routes');
const rooms = require('./routes/rooms.routes');
const hotelCategory = require('./routes/hotelCategory.routes');
const hotel = require('./routes/hotel.routes');
//const hotelreviw = require('./routes/hotelReviewRoutes');

const cors = require('cors');
require('dotenv').config();

const app = express();

// CORS should be applied before routes
app.use(cors({
  origin: 'http://localhost:3001', // Only allow requests from this origin
  // methods: 'GET,POST', // Allow specific HTTP methods
  // allowedHeaders: 'Content-Type,Authorization' // Allow specific headers
  credentials: true   
}));

// Parse incoming requests with JSON payloads
app.use(bodyParser.json());

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/employers', employerRoutes);
app.use('/api/roomCat', roomCategoriesRoutes);
app.use('/api/room', rooms);
app.use('/api/hotelCat', hotelCategory);
app.use('/api/hotels', hotel);
//app.use('/api/', hotelreviw);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
