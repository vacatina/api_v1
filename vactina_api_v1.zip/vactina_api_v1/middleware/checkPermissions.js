const db = require('../config/db.config'); // Assuming you use this for DB connection

const checkPermissions = (resource, action) => {
  return (req, res, next) => {

    const userId = req.user.id;

    ///const userId = req.userId; // Assuming userId is stored in req after authentication

 

    const query = `
      SELECT p.resource, p.action
      FROM users u
      JOIN roles r ON u.role_id = r.id
      JOIN role_permissions rp ON r.id = rp.role_id
      JOIN permissions p ON rp.permission_id = p.id
      WHERE u.id = ? AND p.resource = ? AND p.action = ?
    `;

    db.query(query, [userId, resource, action], (err, result) => {
      if (err) {
        return res.status(500).send({ message: 'Server error' });
      }

      if (result.length === 0) {
        return res.status(403).send({ message: `Unauthorized: You do not have permission to ${action} ${resource}.` });
      }

      next(); // User has the permission, proceed to the next middleware or route handler
    });
  };
};

module.exports = checkPermissions;
